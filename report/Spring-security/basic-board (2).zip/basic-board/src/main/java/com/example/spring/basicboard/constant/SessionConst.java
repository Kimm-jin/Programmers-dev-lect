package com.example.spring.basicboard.constant;

public final class SessionConst {
    public static final String USER_ID = "userId";
    public static final String USER_NAME = "userName";

    // 이 클래스는 상수 모음일 뿐 인스턴스를 만들 이유가 없으므로 private생성자로 New를 막는다.
    private SessionConst(){};
}
