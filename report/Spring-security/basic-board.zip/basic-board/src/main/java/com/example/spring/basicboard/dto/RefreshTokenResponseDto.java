package com.example.spring.basicboard.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class RefreshTokenResponseDto {

    private boolean validated;
    private String accessToken;
    private String refreshToken;
}
